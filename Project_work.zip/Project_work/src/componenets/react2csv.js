import { CSVLink } from "react-csv";
import Button from '@mui/material/Button';
import moment from "moment";

export const ReactCsv = () => {
    const createCsvFileName = ()=> `data_${moment().format()}.csv`;
    const headers = [
        { label: 'Name', key: 'name' },
        { label: 'Description', key: 'description' },
        { label: 'SuggestedRoles', key: 'suggestedRoles' }
    ];

    const csvData = [{
        name: 'Data science training',
        description: 'Data Science certification training',
      
        suggestedRoles: [{
            id: 16,
            category: 'DEVELOPER',
            name: 'Data Engineer'
          },
 
          {
            id: 17,
            category: 'mariselvam',
            name: 'mariselvam'
          }
        ]
      }, {
        name: 'AWS',
        description: 'AWS certification training',
      
        suggestedRoles: [{
            id: 16,
            category: 'DEVELOPER',
            name: 'Cloud Engineer'
          },
          {
            id: 17,
            category: 'Sree',
            name: 'Sree'
          }
        ]
      }];

    let data = []
    csvData.forEach(item => {
        data.push({
            name: item.name,
            description: item.description,
            suggestedRoles: item.suggestedRoles[0].name
            
        });
        
        for (let i = 1; i < item.suggestedRoles.length; i++) {
            const role = item.suggestedRoles[i];
            data.push({
                name: '',
                description: '',
                suggestedRoles: role.name
            });
        }
    });
    console.log(data);

    return (
        <CSVLink
            data={data}
            headers={headers}
            filename={createCsvFileName()}
            target="_blank"
            style={{ textDecoration: 'none', outline: 'none', height: '5vh' }}
        >
            <Button variant="contained" color="secondary" style={{ height: '100%' }}>
                Download CSV
            </Button>
        </CSVLink>
    );
};