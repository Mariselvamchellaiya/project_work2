import "./App.css";
// import { ReactCsv } from "./componenets/react2csv";

import img1 from "./imges/img1.jpg";
import img2 from "../src/imges/img2.jpg";
import img3 from "../src/imges/img3.jpg";
import img4 from "../src/imges/img4.jpg";

function App() {
  return (
    <>
      <div className="container">
        {/* <ReactCsv></ReactCsv> */}
        <h1>advantages at randstad</h1>
        <h6>
          At Randstad,the focus is on the employees.Find out more about your
          benefits as an employee at Randstad
        </h6>
        <div className="imcontner">
          <img
            src={img1}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">randstand skilling acdemy</div>
          </div>
          <img
            src={img2}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">rewrds and recognition</div>
          </div>
          <img
            src={img3}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">equity,diversity & inclution</div>
          </div>
          <img
            src={img4}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">workforce insights</div>
          </div>

          {/* <div className="imgcontainer">
          <img
            src={img1}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">randstand skilling acdemy</div>
          </div>

          <div className="imgcontainer">
          <img
            src={img3}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">randstand skilling acdemy</div>
          </div>

          <div className="imgcontainer">
          <img
            src={img4}
            alt="img1"
            className="img"
            width="200px"
            height="250px"
          ></img>
          <div className="ovrelay">
            <div className="text">randstand skilling acdemy</div>
          </div> */}

          {/* <img src={img2} alt="img2" width="200px" height="250px"></img>
          <div className="text">
            <div className="textcontent">randstad skilling academy</div>
          </div>
          <img src={img3} alt="img3" width="200px" height="250px"></img>
          <div className="text">equity,diversity & inclusion</div>
          <img src={img4} alt="img4" width="200px" height="250px"></img>
          <div className="text">workforce insights</div> */}
        </div>
      </div>
    </>
  );
}

export default App;
